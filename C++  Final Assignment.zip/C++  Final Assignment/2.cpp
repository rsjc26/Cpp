//Set - 1
//Question:4 In this question, you are given a binary string of length T. Now you need to create two permutations of this string: S1 and S2 such that the ‘longest common subsequence’ between the two newly created strings is smallest.



#include <iostream>
#include<cstring>
using namespace std;

void longstring(char *S1, char *S2, int m, int n) 
{
  int str[m + 1][n + 1];


  
  for (int i = 0; i <= m; i++) 
  {
    for (int j = 0; j <= n; j++) 
    
    {
      
      if (i == 0 || j == 0)
      {
        str[i][j] = 0;
      }
      
      else if (S1[i - 1] == S2[j - 1])
      {
        str[i][j] = str[i - 1][j - 1] + 1;
      }
      
      else
      {
        str[i][j] = max(str[i - 1][j], str[i][j - 1]);
      }
    }
  }

//Finding the index

  int index = str[m][n];
  char longstring[index + 1];
  longstring[index] = '\0';

  int i = m, j = n;
  
  while (i > 0 && j > 0) 
  {
        if (S1[i - 1] == S2[j - 1])
        {
          longstring[index - 1] = S1[i - 1];
          
          i--;
          j--;
          index--;
        }

        else if (str[i - 1][j] > str[i][j - 1])
        {
          i--;
        }
        
        else
        {
          j--;
        }
  }
  
 // Subsequence of string Printing
  
        cout << "S1 : " << S1 << "\nS2 : " << S2 << "\nLCS: " << longstring << "\n";
}

//Finding th Length of s

        int s( char *S1, char *S2, int m, int n )
        {
        	if (m == 0 || n == 0)
        	{
        		return 0;
        	}
        	
        	if (S1[m-1] == S2[n-1])
        	{
        		return 1 + s(S1, S2, m-1, n-1);
        	}
        	
        	else
        	{
        		return max(s(S1, S2, m, n-1), s(S1, S2, m-1, n));
        	}
        }


int main()
{
    
  char S1[] = "110";
  char S2[] = "011";
  int m = strlen(S1);
  int n = strlen(S2);

  longstring(S1, S2, m, n);
  cout<<"Length: "<< s( S1, S2, m, n ) ;
	
	return 0;
}
